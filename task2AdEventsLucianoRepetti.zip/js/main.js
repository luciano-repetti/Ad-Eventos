function addCards(){
    var templateHtml = ""
    for (var i = 0; i < data.eventos.length; i++){
        templateHtml += `
        <div class="target d-flex align-items-center justify-content-between flex-column p-3">
            <img src="${data.eventos[i].image}" alt="" width="100%">
            <div class="d-flex flex-column align-items-center">
                <h3>${data.eventos[i].name}</h3>
                <p>${data.eventos[i].description}</p>
            </div>
            <div class="container-fluid d-flex align-items-center justify-content-between mt-3">
                <p>price: $${data.eventos[i].price}</p>
                <a href="./html/infocard.html">Ver mas</a>
            </div>
        </div>
        `
    }
    var myelement = document.querySelector("#contenedorCards");
    if(typeof(myelement) != 'undefined' && myelement != null) {
        myelement.innerHTML = templateHtml;
    }
}

addCards()

function addCardsPast() {
    let templateHtml1 = ""
        for (var i = 0; i < data.eventos.length; i++){
            if (data.fechaActual > data.eventos[i].date){
                templateHtml1 += `
                <div class="target d-flex align-items-center justify-content-between flex-column p-3">
                    <img src="${data.eventos[i].image}" alt="" width="100%">
                    <div class="d-flex flex-column align-items-center">
                        <h3>${data.eventos[i].name}</h3>
                        <p>${data.eventos[i].description}</p>
                    </div>
                    <div class="container-fluid d-flex align-items-center justify-content-between mt-3">
                        <p>price: $${data.eventos[i].price}</p>
                        <a href="../html/infocard.html">Ver mas</a>
                    </div>
                </div>
            `
            }
        }
        var myelement1 = document.querySelector("#contenedorCardsPast");
        if(typeof(myelement1) != 'undefined' && myelement1 != null) {
            myelement1.innerHTML = templateHtml1;
        }
}

addCardsPast()

function addCardsUp() {
    let templateHtml2 = ""
    for (var i = 0; i < data.eventos.length; i++){
        if (data.fechaActual < data.eventos[i].date){
            templateHtml2 += `
            <div class="target d-flex align-items-center justify-content-between flex-column p-3">
                <img src="${data.eventos[i].image}" alt="" width="100%">
                <div class="d-flex flex-column align-items-center">
                    <h3>${data.eventos[i].name}</h3>
                    <p>${data.eventos[i].description}</p>
                </div>
                <div class="container-fluid d-flex align-items-center justify-content-between mt-3">
                    <p>price: $${data.eventos[i].price}</p>
                    <a href="../html/infocard.html">Ver mas</a>
                </div>
            </div>
            `
        }
    }
    let myelement2 = document.querySelector("#contenedorCardsUp");
    if(typeof(myelement2) != 'undefined' && myelement2 != null) {
        myelement2.innerHTML = templateHtml2;
    }
}

addCardsUp()